# ShareWin Materials — Cloudflare Pages 部署说明

## 项目结构
```
sharewin-site/
├── index.html              # 首页（含产品列表 + 联系表单 + Turnstile）
├── functions/
│   └── api/
│       └── contact.js      # Pages Function：收表单 → 验 Turnstile → 发邮件
├── robots.txt
├── sitemap.xml
└── README.md
```

## 一、本地预览
浏览器直接打开 `index.html` 即可看样式（表单提交需部署到 Pages 后才生效）。

## 二、推送到 GitHub
```bash
cd sharewin-site
git init
git add .
git commit -m "Initial website commit"
git branch -M main
git remote add origin https://github.com/Changfengxie/sharewin-site.git
git push -u origin main
```

## 三、Cloudflare Pages 构建配置
- Framework preset：**None**
- Build command：留空
- Output directory：留空（或 `/`）
- Production branch：`main`

## 四、控制台三处必开（核心）

### 1. Turnstile
- 左侧 `Turnstile → Add widget`
- 域名填 `sharewinmaterials.com`，模式选 **Managed**
- 拿到 **Site Key** 和 **Secret Key**
- 把 `index.html` 里的 `YOUR_TURNSTILE_SITE_KEY` 替换为真实 Site Key

### 2. Email Sending + Email Routing
- 左侧 `Compute → Email → Email Sending → Onboard Domain`，选你的域名，Cloudflare 自动加 MX/SPF/DKIM/DMARC
- 左侧 `Email → Email Routing`：
  - 创建自定义地址 `no-reply@sharewinmaterials.com`，路由到你的真实邮箱（验证）
  - 把 `297347085@qq.com` 和 `xiechangfeng@hotmail.com` 都加为**已验证的目的地邮箱**

### 3. Pages 项目环境变量 + Binding
控制台 → 你的 Pages 项目 → **Settings → Environment variables**（全部选 Encrypt）：
| 变量名 | 值 |
|---|---|
| `TURNSTILE_SECRET_KEY` | Turnstile 的 Secret Key |
| `RECIPIENT_EMAIL_1` | `297347085@qq.com` |
| `RECIPIENT_EMAIL_2` | `xiechangfeng@hotmail.com` |
| `FROM_ADDRESS` | `no-reply@sharewinmaterials.com` |

→ **Settings → Functions → Bindings → Add binding**：
- 类型：**Email**
- Binding name：**`EMAIL`**（必须与此名一致，代码里用 `env.EMAIL`）
- 选已 Onboard 的域名，允许发送到上述两个收件邮箱

## 五、必改的内容
1. `index.html` 中 `YOUR_TURNSTILE_SITE_KEY` → 替换为真实 Site Key
2. 6 大类产品的 `📷 ... Photo` 占位 → 替换为真实产品图（webp，<150KB）
3. 文案中的规格、材质用英文买家搜索词，方便 Google 收录

## 六、SEO 上线
1. 去 [Google Search Console](https://search.google.com/search-console) 添加 `sharewinmaterials.com`，验证后提交 `sitemap.xml`
2. 在 Cloudflare 控制台开 **Web Analytics**（免费、无 cookie）

## 七、故障排查
- **表单 403**：Turnstile Secret 填错、或前端 sitekey 未替换
- **表单 500**：检查 EMAIL binding 名是否为 `EMAIL`、FROM_ADDRESS 是否为域名下已建好的自定义地址
- **收不到邮件**：确认两个收件邮箱在 Email Routing 里已"验证"、FROM_ADDRESS 在路由表里存在
- **POST 405**：确认 `functions/api/contact.js` 已推到仓库并被 Pages 识别（部署日志可见）
