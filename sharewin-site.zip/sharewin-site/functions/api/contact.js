// functions/api/contact.js
// Cloudflare Pages Function — handles POST from the contact form.
// Required bindings (set in Pages Settings → Environment variables + Bindings):
//   TURNSTILE_SECRET_KEY  (Encrypt)
//   RECIPIENT_EMAIL_1     e.g. 297347085@qq.com   (Encrypt)
//   RECIPIENT_EMAIL_2     e.g. xiechangfeng@hotmail.com (Encrypt)
//   EMAIL binding name = "EMAIL"  (Bindings → Add → Email)
//   FROM_ADDRESS          must be a custom address on your domain, e.g. no-reply@sharewinmaterials.com

export async function onRequestPost(context) {
  const { request, env } = context;
  const formData = await request.formData();

  const name = (formData.get('name') || '').toString().trim();
  const email = (formData.get('email') || '').toString().trim();
  const company = (formData.get('company') || '').toString().trim();
  const product = (formData.get('product') || '').toString().trim();
  const message = (formData.get('message') || '').toString().trim();
  const token = (formData.get('cf-turnstile-response') || '').toString().trim();
  const ip = request.headers.get('CF-Connecting-IP') || '';

  // Basic validation
  if (!name || !email || !message || !token) {
    return new Response('Missing required fields', { status: 400 });
  }
  // Rudimentary email format check
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return new Response('Invalid email format', { status: 400 });
  }

  // 1) Verify Turnstile
  const verifyRes = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      secret: env.TURNSTILE_SECRET_KEY,
      response: token,
      remoteip: ip,
    }),
  });
  const verifyJson = await verifyRes.json();
  if (!verifyJson.success) {
    return new Response('Bot verification failed', { status: 403 });
  }

  // 2) Build email body
  const subject = `New inquiry from ${name}${company ? ' (' + company + ')' : ''}`;
  const text =
    `Name: ${name}\n` +
    `Email: ${email}\n` +
    `Company: ${company || '-'}\n` +
    `Product: ${product || '-'}\n` +
    `IP: ${ip}\n` +
    `\nMessage:\n${message}\n`;

  // 3) Send to both recipient addresses
  const recipients = [env.RECIPIENT_EMAIL_1, env.RECIPIENT_EMAIL_2].filter(Boolean);
  const fromAddr = env.FROM_ADDRESS || 'no-reply@sharewinmaterials.com';

  try {
    for (const to of recipients) {
      await env.EMAIL.send({
        to,
        from: fromAddr,
        subject,
        text,
      });
    }
  } catch (e) {
    return new Response('Mail send error: ' + e.message, { status: 500 });
  }

  return new Response('OK', { status: 200 });
}

// Reject anything that isn't POST
export async function onRequest(context) {
  if (context.request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }
  return onRequestPost(context);
}
